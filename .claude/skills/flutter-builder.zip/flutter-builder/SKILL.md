---
name: flutter-builder
description: 用于 Flutter 项目打包、构建和资源处理的完整工作流程。支持 Android APK/AAB、iOS IPA 的构建，代码格式化，资源处理，以及构建前检查。适用于需要打包 Flutter 应用到 PGY、Google Play Store 或 App Store 的场景。
---

# Flutter Builder Skill

Flutter 项目构建、打包和资源处理的自动化工具集。

## 何时使用此 Skill

当用户需要：
- 打包 Flutter 应用（Android APK/AAB 或 iOS IPA）
- 配置应用图标和闪屏页
- 格式化 Dart 代码
- 处理图片资源和代码生成
- 执行构建前环境检查

## 环境要求

- Flutter 3.35.4
- Dart 3.9.2

## 快速开始

### 构建 Android APK（PGY 混淆版本）

```bash
./scripts/build_android_apk.sh
```

该脚本会自动：
1. 执行 `before_build.sh pgy`（如果存在）
2. 运行 `flutter pub get`
3. 构建混淆版本的 APK（arm64，分包）
4. 保存调试信息到 `./debug_info/`

输出位置：`build/app/outputs/flutter-apk/`

### 构建 Android AAB（Google Play Store）

```bash
./scripts/build_android_aab.sh
```

该脚本会自动：
1. 执行 `before_build.sh google_store`（如果存在）
2. 运行 `flutter pub get`
3. 构建 AAB（arm64）

输出位置：`build/app/outputs/bundle/release/`

### 构建 iOS

#### App Store 版本
```bash
./scripts/build_ios.sh release
```

#### Ad-Hoc 测试版本
```bash
./scripts/build_ios.sh adhoc
```

该脚本会自动：
1. 执行 `before_build.sh apple_store`（对于 release 版本）
2. 运行 `flutter pub get`
3. 构建 IPA

输出位置：`build/ios/ipa/`

**注意**：如果 Ad-Hoc 签名失败，需要使用 Xcode 手动导出。

## 资源处理和配置

### 自动处理所有资源

```bash
./scripts/setup_resources.sh
```

这会执行：
- 更新闪屏页
- 更新应用图标
- 处理图片资源
- 生成代码

### 单独执行特定任务

```bash
# 只更新闪屏页
./scripts/setup_resources.sh splash

# 只更新图标
./scripts/setup_resources.sh icon

# 只处理图片资源
./scripts/setup_resources.sh images

# 只生成代码
./scripts/setup_resources.sh generate
```

**资源文件位置**：
- 闪屏页：`assets/images/splash.png`
- 应用图标：`assets/images/app_icon.png`

## 代码格式化

```bash
./scripts/format_code.sh
```

自动格式化 `lib/` 目录下的所有 Dart 文件（排除 `*.g.dart` 生成文件），页面宽度设置为 120。

## 构建前检查

```bash
./scripts/pre_build_check.sh
```

检查项目包括：
- Flutter 和 Dart 安装及版本
- Flutter 环境状态
- 必需的项目文件（pubspec.yaml、before_build.sh 等）
- 资源文件（splash.png、app_icon.png）

## Flavor 配置

项目支持三种 flavor：
- `pgy` - PGY 分发平台
- `google_store` - Google Play Store
- `apple_store` - Apple App Store

Flavor 配置通过 `before_build.sh` 脚本处理。如果项目中存在该脚本，构建脚本会自动调用它。

## 工作流程示例

### 完整发布流程

1. **准备资源**
```bash
# 替换 assets/images/splash.png 和 app_icon.png
./scripts/setup_resources.sh
```

2. **检查环境**
```bash
./scripts/pre_build_check.sh
```

3. **格式化代码**
```bash
./scripts/format_code.sh
```

4. **构建应用**
```bash
# Android
./scripts/build_android_apk.sh
# 或 AAB
./scripts/build_android_aab.sh

# iOS
./scripts/build_ios.sh release
```

### 快速构建（跳过检查）

直接运行构建脚本：
```bash
./scripts/build_android_apk.sh
```

## 参考文档

完整的使用说明和命令参考，请查看：
- [references/usage.md](references/usage.md) - 原始使用文档

## 故障排查

### 常见问题

**问题：构建失败**
- 运行 `./scripts/pre_build_check.sh` 检查环境
- 确认 Flutter 和 Dart 版本符合要求
- 检查 `pubspec.yaml` 配置是否正确

**问题：iOS 签名失败**
- Ad-Hoc 版本签名失败是正常情况
- 使用 Xcode 打开 `build/ios/archive/*.xcarchive` 手动导出
- 或者使用 App Store 版本（release）

**问题：找不到 before_build.sh**
- 该脚本为可选项，用于 flavor 配置
- 如果不需要多 flavor，可以忽略相关警告

**问题：资源更新失败**
- 确认 `assets/images/` 目录下存在对应的图片文件
- 检查 `pubspec.yaml` 中是否配置了相应的依赖包
- 运行 `flutter pub get` 更新依赖

## 脚本说明

所有脚本位于 `scripts/` 目录：

- `build_android_apk.sh` - Android APK 构建（混淆、分包）
- `build_android_aab.sh` - Android AAB 构建（Google Play）
- `build_ios.sh` - iOS IPA 构建（支持 release/adhoc）
- `setup_resources.sh` - 资源处理和代码生成
- `format_code.sh` - Dart 代码格式化
- `pre_build_check.sh` - 构建前环境检查

所有脚本都包含详细的输出信息和错误处理。
