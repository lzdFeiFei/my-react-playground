#!/bin/bash
set -e

# Flutter 资源处理和代码生成脚本

echo "======================================"
echo "Flutter 资源处理和代码生成"
echo "======================================"

# 更新闪屏页
update_splash() {
    echo ""
    echo "更新闪屏页..."
    if [ -f "assets/images/splash.png" ]; then
        flutter pub run flutter_native_splash:create
        echo "✅ 闪屏页更新完成"
    else
        echo "⚠️  未找到 assets/images/splash.png，跳过闪屏页更新"
    fi
}

# 更新应用图标
update_icon() {
    echo ""
    echo "更新应用图标..."
    if [ -f "assets/images/app_icon.png" ]; then
        flutter pub run flutter_launcher_icons:main
        echo "✅ 应用图标更新完成"
    else
        echo "⚠️  未找到 assets/images/app_icon.png，跳过图标更新"
    fi
}

# 处理图片资源
process_images() {
    echo ""
    echo "处理图片资源..."
    dart run build_runner build
    echo "✅ 图片资源处理完成"
}

# 代码生成
generate_code() {
    echo ""
    echo "生成代码..."
    dart run build_runner build
    echo "✅ 代码生成完成"
}

# 解析参数
if [ $# -eq 0 ]; then
    # 如果没有参数，执行所有任务
    update_splash
    update_icon
    process_images
    generate_code
else
    # 根据参数执行特定任务
    for arg in "$@"; do
        case $arg in
            splash)
                update_splash
                ;;
            icon)
                update_icon
                ;;
            images)
                process_images
                ;;
            generate)
                generate_code
                ;;
            *)
                echo "未知参数: $arg"
                echo "可用参数: splash, icon, images, generate"
                exit 1
                ;;
        esac
    done
fi

echo ""
echo "======================================"
echo "所有任务完成！"
echo "======================================"
