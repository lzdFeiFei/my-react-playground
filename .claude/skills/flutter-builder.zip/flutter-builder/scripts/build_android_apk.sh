#!/bin/bash
set -e

# Flutter Android APK 构建脚本 (PGY 混淆版本)

echo "======================================"
echo "开始构建 Flutter Android APK (PGY)"
echo "======================================"

# 检查是否存在 before_build.sh
if [ -f "./before_build.sh" ]; then
    echo "执行 before_build.sh pgy..."
    ./before_build.sh pgy
else
    echo "警告: before_build.sh 不存在，跳过 flavor 配置"
fi

# 获取依赖
echo "获取 Flutter 依赖..."
flutter pub get

# 清理之前的构建
echo "清理之前的构建..."
rm -rf ./debug_info
mkdir -p ./debug_info

# 构建 APK
echo "开始构建混淆版本 APK..."
flutter build apk \
    --verbose \
    --obfuscate \
    --split-debug-info=./debug_info \
    --target-platform=android-arm64 \
    --split-per-abi

echo ""
echo "======================================"
echo "构建完成！"
echo "======================================"
echo "APK 位置: build/app/outputs/flutter-apk/"
ls -lh build/app/outputs/flutter-apk/*.apk 2>/dev/null || echo "未找到 APK 文件"
echo "调试信息: ./debug_info/"
