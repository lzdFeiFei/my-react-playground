#!/bin/bash
set -e

# Flutter 代码格式化脚本

echo "======================================"
echo "开始格式化 Dart 代码"
echo "======================================"

# 检查是否存在 lib 目录
if [ ! -d "./lib" ]; then
    echo "错误: 未找到 lib 目录"
    exit 1
fi

# 格式化代码（排除生成的文件）
echo "格式化 lib 目录下的 Dart 文件（排除 *.g.dart）..."
find ./lib -name '*.dart' -not -name '*.g.dart' -print0 | xargs -0 dart format --page-width=120

echo ""
echo "======================================"
echo "代码格式化完成！"
echo "======================================"
