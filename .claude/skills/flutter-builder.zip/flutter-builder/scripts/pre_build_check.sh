#!/bin/bash

# Flutter 构建前检查脚本

echo "======================================"
echo "Flutter 构建前环境检查"
echo "======================================"

# 检查 Flutter 是否安装
if ! command -v flutter &> /dev/null; then
    echo "❌ Flutter 未安装或未添加到 PATH"
    exit 1
fi

# 检查 Flutter 版本
echo ""
echo "Flutter 版本信息:"
flutter --version

# 检查 Dart 版本
echo ""
echo "Dart 版本信息:"
dart --version

# 检查 Flutter 环境
echo ""
echo "Flutter 环境检查:"
flutter doctor

# 检查项目文件
echo ""
echo "======================================"
echo "检查项目文件"
echo "======================================"

check_file() {
    if [ -f "$1" ]; then
        echo "✅ $1"
    else
        echo "❌ $1 (缺失)"
    fi
}

check_file "pubspec.yaml"
check_file "before_build.sh"
check_file "assets/images/splash.png"
check_file "assets/images/app_icon.png"

echo ""
echo "======================================"
echo "检查完成！"
echo "======================================"
