#!/bin/bash
set -e

# Flutter Android AAB 构建脚本 (Google Play Store)

echo "======================================"
echo "开始构建 Flutter Android AAB (Google Play)"
echo "======================================"

# 检查是否存在 before_build.sh
if [ -f "./before_build.sh" ]; then
    echo "执行 before_build.sh google_store..."
    ./before_build.sh google_store
else
    echo "警告: before_build.sh 不存在，跳过 flavor 配置"
fi

# 获取依赖
echo "获取 Flutter 依赖..."
flutter pub get

# 构建 AAB
echo "开始构建 AAB..."
flutter build appbundle \
    --verbose \
    --target-platform=android-arm64

echo ""
echo "======================================"
echo "构建完成！"
echo "======================================"
echo "AAB 位置: build/app/outputs/bundle/release/"
ls -lh build/app/outputs/bundle/release/*.aab 2>/dev/null || echo "未找到 AAB 文件"
