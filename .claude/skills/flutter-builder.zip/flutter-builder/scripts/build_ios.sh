#!/bin/bash
set -e

# Flutter iOS 构建脚本

# 默认构建类型为 release
BUILD_TYPE="${1:-release}"

if [ "$BUILD_TYPE" = "release" ]; then
    echo "======================================"
    echo "开始构建 Flutter iOS (App Store)"
    echo "======================================"
    
    # 检查是否存在 before_build.sh
    if [ -f "./before_build.sh" ]; then
        echo "执行 before_build.sh apple_store..."
        ./before_build.sh apple_store
    else
        echo "警告: before_build.sh 不存在，跳过 flavor 配置"
    fi
    
    # 获取依赖
    echo "获取 Flutter 依赖..."
    flutter pub get
    
    # 构建 iOS
    echo "开始构建 iOS Release 版本..."
    flutter build ipa --verbose --release
    
    echo ""
    echo "======================================"
    echo "构建完成！"
    echo "======================================"
    echo "IPA 位置: build/ios/ipa/"
    ls -lh build/ios/ipa/*.ipa 2>/dev/null || echo "未找到 IPA 文件"

elif [ "$BUILD_TYPE" = "adhoc" ]; then
    echo "======================================"
    echo "开始构建 Flutter iOS (Ad-Hoc)"
    echo "======================================"
    echo "注意: 如果签名失败，请使用 Xcode 手动导出"
    
    # 获取依赖
    echo "获取 Flutter 依赖..."
    flutter pub get
    
    # 构建 iOS Ad-Hoc
    echo "开始构建 iOS Ad-Hoc 版本..."
    flutter build ipa --verbose --export-method ad-hoc
    
    echo ""
    echo "======================================"
    echo "构建完成！"
    echo "======================================"
    echo "IPA 位置: build/ios/ipa/"
    ls -lh build/ios/ipa/*.ipa 2>/dev/null || echo "未找到 IPA 文件"
    
else
    echo "错误: 未知的构建类型 '$BUILD_TYPE'"
    echo "用法: $0 [release|adhoc]"
    exit 1
fi
