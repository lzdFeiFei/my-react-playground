# Flutter 项目使用指南

## 开发环境
Flutter 3.35.4
Dart 3.9.2

## 工程配置

- 修改闪屏页

  - assets/images/splash.png

  ``` shell
      flutter pub run flutter_native_splash:create
  ```

- Change app launch icon (replace assets/images/app_icon.png with your app icon) then run this command
    ``` shell
    flutter pub run flutter_launcher_icons:main
    ```

## 图片资源处理
```shell
dart run build_runner build
```

## 代码生成
```shell
dart run build_runner build
```

## 格式化
```shell
find ./lib -name '*.dart' -not -name '*.g.dart' -print0 | xargs -0 dart format --page-width=120
```

## flavor
参考：before_build.sh
pgy
google_store
apple_store

## 编译混淆版本APK(PGY)
```shell
./before_build.sh pgy
flutter pub get
flutter build apk --verbose --obfuscate --split-debug-info=./debug_info --target-platform=android-arm64 --split-per-abi
```

## 编译AAB
```shell
./before_build.sh google_store
flutter pub get
flutter build appbundle --verbose --target-platform=android-arm64
```

## 编译iOS
### 编译iOS正式版本
```shell
./before_build.sh apple_store
flutter pub get
flutter build ipa --verbose --release
```

### 编译iOS测试版本
签名失败，先用xcode导出
```shell
flutter build ipa --verbose --export-method ad-hoc
```
